﻿using Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Collections.Specialized.BitVector32;

namespace Scenes.Intro
{
    internal class IntroScene : IScene
    {
        public void Run(out GameState nextState)
        {
            Console.Clear();
            Console.WriteLine("스파르타 던전에 오신 여러분 환영합니다.\n");

            //추후 메뉴 추가 여지 있어 리팩토링할지 고민중
            Console.WriteLine("1. 새로 시작하기");
            Console.WriteLine("2. 불러오기");

            Console.WriteLine("\n원하시는 행동을 선택해주세요.");
            Console.Write(">> ");
            string inputAction = Console.ReadLine();

            switch (inputAction)
            {
                case "1":
                    nextState = GameState.CreateCharacter;
                    break;
                case "2":
                    nextState = GameState.LoadCharacter;
                    break;
                default:
                    nextState = GameState.Intro;
                    Console.WriteLine("\n잘못된 입력입니다.");
                    Console.WriteLine("계속하려면 아무 키나 누르세요.");
                    Console.ReadKey();
                    break;
            }
        }
    }
}
