﻿using Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Scenes.Intro
{
    internal class CreateCharacterScene : IScene
    {
        public void Run(out GameState nextState)
        {
            Console.Clear();
            Console.WriteLine("스파르타 던전에 오신 여러분 환영합니다.\n");
            Console.WriteLine("원하시는 이름을 설정해주세요.(공백 입력 시 이전 화면으로 돌아갑니다.)\n");
            Console.Write(">> ");
            string inputName = Console.ReadLine();

            if (string.IsNullOrWhiteSpace(inputName))
            {
                Console.WriteLine("\n입력이 취소되었습니다. 이전 화면으로 돌아갑니다.");
                Console.WriteLine("계속하려면 아무 키나 누르세요.");
                Console.ReadKey();
                nextState = GameState.Intro;
                return;
            }

            bool rightInput = false;
            nextState = GameState.Exit; //오류 방지용 임시 저장

            while (!rightInput)
            {
                Console.Clear();
                Console.WriteLine($"\n입력하신 이름은 '{inputName}'입니다.\n");
                Console.WriteLine("1. 저장");
                Console.WriteLine("2. 취소");
                Console.WriteLine("\n원하시는 행동을 선택해주세요.");
                Console.Write(">> ");
                string inputAction = Console.ReadLine();

                switch (inputAction)
                {
                    case "1":
                        // 이름 저장 및 player 생성자 호출 (아직 미구현)
                        Console.WriteLine($"\n'{inputName}' 캐릭터가 저장되었습니다!");
                        Console.ReadKey();
                        nextState = GameState.Main;
                        rightInput = true;
                        break;
                    case "2":
                        Console.WriteLine("\n이름 입력을 취소하고 이전 화면으로 돌아갑니다.");
                        Console.ReadKey();
                        nextState = GameState.Intro;
                        rightInput = true;
                        break;
                    default:
                        Console.WriteLine("\n잘못된 입력입니다.");
                        Console.WriteLine("계속하려면 아무 키나 누르세요.");
                        Console.ReadKey();
                        break;
                }
            }
        }
    }
}
